
close all
clc
times=3;
setName='set4';
%goalFile=importdata(strcat('dataset/',setName,'/goal.dat'));
for k=1:times
    file=dir(strcat('dataset/',setName,'/*'));
    result=cell(size(file,1),3);%1:result 2:fit 3:time
    for i=1:size(file,1)
        if strcmp(file(i).name,'.')||strcmp(file(i).name,'..')||strcmp(file(i).name,'goal.dat') || strcmp(file(i).name,'.DS_Store')
            continue;
        end
%         %get goal
%         for j=1:size(goalFile.data,1)
%            if strcmp(goalFile.textdata{j,1},file(i).name)
%                goal=goalFile.data(j);
%            end
%         end
        start=clock;
        result{i,1}=runOneData(setName,file(i).name,strcat('result/',setName,'/',date,'_',num2str(k),'_','300_',file(i).name),0);
        result{i,3}=etime(clock,start);
        result{i,2}=result{i,1}{1,3};
        fprintf('%s\t%s\tFit:%f\t��ʱ%fs\n\n',setName,file(i).name,result{i,2},result{i,3});
    end
    
    fid=fopen(strcat('result/',setName,'/',num2str(k),'.txt'),'w');
    for i=1:size(file,1)
        if strcmp(file(i).name,'.')||strcmp(file(i).name,'..')||strcmp(file(i).name,'goal.dat')
            continue;
        end
        fprintf(fid,'%s\t%f\t%fs\r\n',file(i).name,result{i,1}{1,3},result{i,3});
    end
    fclose(fid);
    
    
end




