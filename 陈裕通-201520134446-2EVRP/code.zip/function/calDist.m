function Dist = calDist(PosArr,onePos )
Dist=zeros(size(PosArr,1),2);
for i=1:size(PosArr,1)
   Dist(i,:)=[PosArr(i,1),sqrt((onePos(1)-PosArr(i,2)).^2+(onePos(2)-PosArr(i,3)).^2)];
end
end
