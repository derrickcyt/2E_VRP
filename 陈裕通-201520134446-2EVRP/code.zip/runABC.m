
close all
clc
setName='set4';
filename='Instance50-s2-02.dat';
outputpath=strcat('result/test/',date,'_',filename);
start=clock;
GlobalMinResult=runOneData(setName,filename,outputpath,0);
fprintf('��ʱ:%f��\n',etime(clock,start));
fid=fopen(outputpath);
temp=fgets(fid);
while temp~=-1
    fprintf('%s',temp);
    temp=fgets(fid);
end
fclose(fid);